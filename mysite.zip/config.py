import os
from app.web_dict import web_dict
basedir = os.path.abspath(os.path.dirname(__file__))
TOP_LEVEL_DIR = basedir
		

class Config:
	SECRET_KEY = os.environ.get('SECRET_KEY') or 'cash2cash'
	SQLALCHEMY_COMMIT_ON_TEARDOWN = True
	SQLALCHEMY_TRACK_MODIFICATIONS = True
	MAIL_SUBJECT_PREFIX = '[FanGrant]'
	MAIL_SENDER = os.environ.get('ADMIN') or 'fi167sh@gmail.com'
	MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'fi167sh@gmail.com'
	MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'vbxtdlofcxnobajd'
	ADMIN = os.environ.get('ADMIN') or web_dict.email
	#Uploads configuration
	MAX_CONTENT_LENGTH = 388800 * 1024 * 1024
	UPLOADS_DEFAULT_DEST = TOP_LEVEL_DIR + '/app/static/web_files/'
	UPLOADS_DEFAULT_URL = '/static/web_files/'
	 
	UPLOADED_IMAGES_DEST = TOP_LEVEL_DIR + '/app/static/web_files/photo/'
	UPLOADED_IMAGES_URL = '/static/web_files/photo/'

	POSTS_PER_PAGE = 10
	COMMENTS_PER_PAGE = 5
	FOLLOWERS_PER_PAGE = 10
	FRIENDS_PER_PAGE = 10
	FRIEND_REQUESTS_PER_PAGE = 10

	@staticmethod
	def init_app(app):
		pass


class DevelopmentConfig(Config):
	DEBUG = True
	MAIL_SERVER = 'smtp.googlemail.com'
	MAIL_PORT = 587
	MAIL_USE_TLS = True
	SQLALCHEMY_DATABASE_URI = os.environ.get('DEV_DATABASE_URL') or \
	'sqlite:///' + os.path.join(basedir, 'data-dev.sqlite')

class TestingConfig(Config):
	TESTING = True
	SQLALCHEMY_DATABASE_URI = os.environ.get('TEST_DATABASE_URL') or \
	'sqlite:///' + os.path.join(basedir, 'data-test.sqlite')
	

class ProductionConfig(Config):
	DEBUG = True
	MAIL_SERVER = 'smtp.googlemail.com'
	MAIL_PORT = 587
	MAIL_USE_TLS = True
	SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
	'sqlite:///' + os.path.join(basedir, 'data.sqlite')

config = {
	'development': DevelopmentConfig,
	'testing': TestingConfig,
	'production': ProductionConfig,
	'default': DevelopmentConfig
	}


